package com.inventory.service;

import com.inventory.exception.ValidationException;
import com.inventory.model.Product;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class InventoryServiceTest {
    @Test void productConstructorOverloadSetsFields(){
        Product p=new Product("A-1","Mouse","Accessories",500,10,2);
        assertEquals("A-1",p.getSku());assertEquals(10,p.getStock());
    }
    @Test void lowStockRuleWorks(){
        Product p=new Product("A","Test","General",1,2,2);
        assertTrue(p.isLowStock());
        p.setStock(3);assertFalse(p.isLowStock());
    }
    @Test void validationExceptionIsRuntimeException(){
        assertThrows(ValidationException.class,()->{throw new ValidationException("Invalid input");});
    }
}
