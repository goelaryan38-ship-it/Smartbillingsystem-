package com.inventory.dao;

import java.util.List;
import java.util.Optional;

public interface Repository<T> {
    List<T> findAll() throws Exception;
    Optional<T> findById(int id) throws Exception;
    T save(T item) throws Exception;
    boolean delete(int id) throws Exception;
}
