package com.inventory.dao;

import com.inventory.config.Database;
import com.inventory.model.*;
import java.sql.*;
import java.util.*;

public class SaleDao {
    public int createSale(String invoice, String customer, double subtotal, double tax, double total,
                          List<SaleItemRequest> items, Map<Integer, Product> products) throws SQLException {
        String saleSql="INSERT INTO sales(invoice_no,customer_name,subtotal,tax,grand_total) VALUES(?,?,?,?,?)";
        String itemSql="INSERT INTO sale_items(sale_id,product_id,product_name,quantity,unit_price,line_total) VALUES(?,?,?,?,?,?)";
        try(Connection c=Database.getConnection()) {
            c.setAutoCommit(false);
            try {
                int saleId;
                try(PreparedStatement ps=c.prepareStatement(saleSql,Statement.RETURN_GENERATED_KEYS)) {
                    ps.setString(1,invoice); ps.setString(2,customer); ps.setDouble(3,subtotal); ps.setDouble(4,tax); ps.setDouble(5,total);
                    ps.executeUpdate(); try(ResultSet keys=ps.getGeneratedKeys()){keys.next(); saleId=keys.getInt(1);}
                }
                ProductDao productDao=new ProductDao();
                try(PreparedStatement ps=c.prepareStatement(itemSql)) {
                    for(SaleItemRequest item:items) {
                        Product p=products.get(item.getProductId());
                        productDao.reduceStock(c,p.getId(),item.getQuantity());
                        ps.setInt(1,saleId); ps.setInt(2,p.getId()); ps.setString(3,p.getName());
                        ps.setInt(4,item.getQuantity()); ps.setDouble(5,p.getPrice());
                        ps.setDouble(6,p.getPrice()*item.getQuantity()); ps.addBatch();
                    }
                    ps.executeBatch();
                }
                c.commit(); return saleId;
            } catch(Exception ex) { c.rollback(); if(ex instanceof SQLException se) throw se; throw new SQLException(ex); }
            finally { c.setAutoCommit(true); }
        }
    }
    public List<Map<String,Object>> findRecent() throws SQLException {
        List<Map<String,Object>> out=new ArrayList<>();
        String sql="SELECT id,invoice_no,customer_name,subtotal,tax,grand_total,created_at FROM sales ORDER BY id DESC LIMIT 100";
        try(Connection c=Database.getConnection(); PreparedStatement ps=c.prepareStatement(sql); ResultSet rs=ps.executeQuery()) {
            while(rs.next()) { Map<String,Object> m=new LinkedHashMap<>(); m.put("id",rs.getInt("id"));m.put("invoiceNo",rs.getString("invoice_no"));
                m.put("customerName",rs.getString("customer_name"));m.put("subtotal",rs.getDouble("subtotal"));
                m.put("tax",rs.getDouble("tax"));m.put("grandTotal",rs.getDouble("grand_total"));m.put("createdAt",rs.getTimestamp("created_at").toString());out.add(m); }
        }
        return out;
    }
    public Map<String,Object> summary() throws SQLException {
        Map<String,Object> m=new LinkedHashMap<>();
        try(Connection c=Database.getConnection(); PreparedStatement ps=c.prepareStatement(
            "SELECT COUNT(*) bills, COALESCE(SUM(grand_total),0) revenue FROM sales"); ResultSet rs=ps.executeQuery()) {
            rs.next();m.put("bills",rs.getInt("bills"));m.put("revenue",rs.getDouble("revenue"));
        }
        return m;
    }
}
