package com.inventory.dao;

import com.inventory.config.Database;
import com.inventory.model.Product;
import java.sql.*;
import java.util.*;

public class ProductDao implements Repository<Product> {
    private Product map(ResultSet rs) throws SQLException {
        return new Product(rs.getInt("id"), rs.getString("sku"), rs.getString("name"),
            rs.getString("category"), rs.getDouble("price"), rs.getInt("stock"), rs.getInt("reorder_level"));
    }
    @Override public List<Product> findAll() throws SQLException {
        List<Product> list = new ArrayList<>();
        String sql = "SELECT * FROM products ORDER BY id DESC";
        try (Connection c=Database.getConnection(); PreparedStatement ps=c.prepareStatement(sql); ResultSet rs=ps.executeQuery()) {
            while(rs.next()) list.add(map(rs));
        } finally { /* JDBC resources are closed by try-with-resources. */ }
        return list;
    }
    @Override public Optional<Product> findById(int id) throws SQLException {
        try(Connection c=Database.getConnection(); PreparedStatement ps=c.prepareStatement("SELECT * FROM products WHERE id=?")) {
            ps.setInt(1,id); try(ResultSet rs=ps.executeQuery()){ return rs.next()?Optional.of(map(rs)):Optional.empty(); }
        }
    }
    @Override public Product save(Product p) throws SQLException {
        if(p.getId()==0) {
            String sql="INSERT INTO products(sku,name,category,price,stock,reorder_level) VALUES(?,?,?,?,?,?)";
            try(Connection c=Database.getConnection(); PreparedStatement ps=c.prepareStatement(sql,Statement.RETURN_GENERATED_KEYS)) {
                bind(ps,p); ps.executeUpdate(); try(ResultSet keys=ps.getGeneratedKeys()){if(keys.next())p.setId(keys.getInt(1));}
            }
        } else {
            String sql="UPDATE products SET sku=?,name=?,category=?,price=?,stock=?,reorder_level=? WHERE id=?";
            try(Connection c=Database.getConnection(); PreparedStatement ps=c.prepareStatement(sql)) {
                bind(ps,p); ps.setInt(7,p.getId()); ps.executeUpdate();
            }
        }
        return p;
    }
    private void bind(PreparedStatement ps, Product p) throws SQLException {
        ps.setString(1,p.getSku()); ps.setString(2,p.getName()); ps.setString(3,p.getCategory());
        ps.setDouble(4,p.getPrice()); ps.setInt(5,p.getStock()); ps.setInt(6,p.getReorderLevel());
    }
    @Override public boolean delete(int id) throws SQLException {
        try(Connection c=Database.getConnection(); PreparedStatement ps=c.prepareStatement("DELETE FROM products WHERE id=?")) {
            ps.setInt(1,id); return ps.executeUpdate()>0;
        }
    }
    public void reduceStock(Connection c, int productId, int quantity) throws SQLException {
        try(PreparedStatement ps=c.prepareStatement("UPDATE products SET stock=stock-? WHERE id=? AND stock>=?")) {
            ps.setInt(1,quantity); ps.setInt(2,productId); ps.setInt(3,quantity);
            if(ps.executeUpdate()==0) throw new SQLException("Insufficient stock for product ID " + productId);
        }
    }
}
