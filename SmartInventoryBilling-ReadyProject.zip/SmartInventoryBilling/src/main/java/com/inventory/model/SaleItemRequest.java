package com.inventory.model;

public class SaleItemRequest {
    private final int productId, quantity;
    public SaleItemRequest(int productId, int quantity) { this.productId=productId; this.quantity=quantity; }
    public int getProductId(){return productId;} public int getQuantity(){return quantity;}
}
