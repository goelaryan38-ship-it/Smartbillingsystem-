package com.inventory.model;

public class Admin extends User {
    public Admin(String name) { super(name, "ADMIN"); }
    @Override public String dashboardMessage() { return "Welcome, " + getName() + " — manage stock and sales."; }
}
