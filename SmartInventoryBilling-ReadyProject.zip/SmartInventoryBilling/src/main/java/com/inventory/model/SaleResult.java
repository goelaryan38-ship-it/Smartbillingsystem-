package com.inventory.model;

import java.util.List;

public class SaleResult {
    private final int id;
    private final String invoiceNo, customerName;
    private final double subtotal, tax, grandTotal;
    private final List<String> itemSummary;
    public SaleResult(int id, String invoiceNo, String customerName, double subtotal, double tax, double grandTotal, List<String> itemSummary) {
        this.id=id; this.invoiceNo=invoiceNo; this.customerName=customerName; this.subtotal=subtotal;
        this.tax=tax; this.grandTotal=grandTotal; this.itemSummary=itemSummary;
    }
    public int getId(){return id;} public String getInvoiceNo(){return invoiceNo;}
    public String getCustomerName(){return customerName;} public double getSubtotal(){return subtotal;}
    public double getTax(){return tax;} public double getGrandTotal(){return grandTotal;}
    public List<String> getItemSummary(){return itemSummary;}
}
