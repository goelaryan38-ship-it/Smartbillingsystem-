package com.inventory.model;

public class Product {
    private int id;
    private String sku, name, category;
    private double price;
    private int stock, reorderLevel;

    public Product() { this(0, "", "", "General", 0.0, 0, 5); }
    public Product(String sku, String name, String category, double price, int stock, int reorderLevel) {
        this(0, sku, name, category, price, stock, reorderLevel);
    }
    public Product(int id, String sku, String name, String category, double price, int stock, int reorderLevel) {
        this.id=id; this.sku=sku; this.name=name; this.category=category;
        this.price=price; this.stock=stock; this.reorderLevel=reorderLevel;
    }
    public int getId(){return id;} public void setId(int id){this.id=id;}
    public String getSku(){return sku;} public void setSku(String sku){this.sku=sku;}
    public String getName(){return name;} public void setName(String name){this.name=name;}
    public String getCategory(){return category;} public void setCategory(String category){this.category=category;}
    public double getPrice(){return price;} public void setPrice(double price){this.price=price;}
    public int getStock(){return stock;} public void setStock(int stock){this.stock=stock;}
    public int getReorderLevel(){return reorderLevel;} public void setReorderLevel(int v){this.reorderLevel=v;}
    public boolean isLowStock(){return stock <= reorderLevel;}
}
