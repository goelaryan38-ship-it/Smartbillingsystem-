package com.inventory.model;

public class Cashier extends User {
    public Cashier(String name) { super(name, "CASHIER"); }
    @Override public String dashboardMessage() { return "Welcome, " + getName() + " — ready to create a bill."; }
}
