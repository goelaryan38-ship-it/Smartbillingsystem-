package com.inventory.controller;

import com.inventory.model.*;
import com.inventory.service.*;
import com.inventory.server.Json;
import java.util.*;

public class ApiController {
    private final InventoryService inventory; private final SalesService sales;
    public ApiController(InventoryService i,SalesService s){inventory=i;sales=s;}
    public String products() throws Exception{return Json.products(inventory.all());}
    public String analytics() throws Exception {
        Map<String,Object> m=new LinkedHashMap<>(inventory.analytics());m.putAll(sales.summary());return Json.map(m);
    }
    public String lowStock() throws Exception{return Json.products(inventory.lowStock());}
    public String recentSales() throws Exception{return Json.listMaps(sales.recent());}
    public String saveProduct(Map<String,String> d) throws Exception {
        Product p=new Product(Integer.parseInt(d.getOrDefault("id","0")),d.getOrDefault("sku",""),d.getOrDefault("name",""),
            d.getOrDefault("category","General"),Double.parseDouble(d.getOrDefault("price","0")),
            Integer.parseInt(d.getOrDefault("stock","0")),Integer.parseInt(d.getOrDefault("reorderLevel","5")));
        return Json.product(inventory.save(p));
    }
    public boolean deleteProduct(int id) throws Exception{return inventory.delete(id);}
    public String createSale(Map<String,String> d) throws Exception {
        String raw=d.getOrDefault("items",""); List<SaleItemRequest> items=new ArrayList<>();
        java.util.regex.Matcher m=java.util.regex.Pattern.compile("\\{\\s*\"productId\"\\s*:\\s*(\\d+)\\s*,\\s*\"quantity\"\\s*:\\s*(\\d+)\\s*}").matcher(raw);
        while(m.find())items.add(new SaleItemRequest(Integer.parseInt(m.group(1)),Integer.parseInt(m.group(2))));
        return Json.sale(sales.create(d.get("customerName"),items));
    }
}
