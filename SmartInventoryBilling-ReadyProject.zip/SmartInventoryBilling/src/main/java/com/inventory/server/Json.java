package com.inventory.server;

import com.inventory.model.*;
import java.util.*;

public final class Json {
    private Json(){}
    public static String escape(String s){return s==null?"":s.replace("\\","\\\\").replace("\"","\\\"").replace("\n","\\n").replace("\r","");}
    public static String product(Product p){return "{\"id\":"+p.getId()+",\"sku\":\""+escape(p.getSku())+"\",\"name\":\""+escape(p.getName())+"\",\"category\":\""+escape(p.getCategory())+"\",\"price\":"+p.getPrice()+",\"stock\":"+p.getStock()+",\"reorderLevel\":"+p.getReorderLevel()+"}";}
    public static String products(List<Product> list){return list.stream().map(Json::product).collect(java.util.stream.Collectors.joining(",","[","]"));}
    public static String map(Map<String,Object> m){StringJoiner j=new StringJoiner(",","{","}");m.forEach((k,v)->j.add("\""+escape(k)+"\":"+value(v)));return j.toString();}
    public static String listMaps(List<Map<String,Object>> list){return list.stream().map(Json::map).collect(java.util.stream.Collectors.joining(",","[","]"));}
    public static String value(Object v){if(v==null)return "null";if(v instanceof Number||v instanceof Boolean)return v.toString();if(v instanceof Collection<?> c)return c.stream().map(x->"\""+escape(String.valueOf(x))+"\"").collect(java.util.stream.Collectors.joining(",","[","]"));return "\""+escape(String.valueOf(v))+"\"";}
    public static String sale(SaleResult s){return "{\"id\":"+s.getId()+",\"invoiceNo\":\""+escape(s.getInvoiceNo())+"\",\"customerName\":\""+escape(s.getCustomerName())+"\",\"subtotal\":"+s.getSubtotal()+",\"tax\":"+s.getTax()+",\"grandTotal\":"+s.getGrandTotal()+",\"items\":"+s.getItemSummary().stream().map(x->"\""+escape(x)+"\"").collect(java.util.stream.Collectors.joining(",","[","]"))+"}";}
    public static Map<String,String> parseFlat(String body){
        Map<String,String> out=new HashMap<>(); java.util.regex.Matcher m=java.util.regex.Pattern.compile("\"([^\"]+)\"\\s*:\\s*(\"((?:\\\\.|[^\"])*)\"|[^,}]+)").matcher(body);
        while(m.find()){String val=m.group(3)!=null?m.group(3).replace("\\\"","\"").replace("\\n","\n"):m.group(2).trim();out.put(m.group(1),val);}return out;
    }
}
