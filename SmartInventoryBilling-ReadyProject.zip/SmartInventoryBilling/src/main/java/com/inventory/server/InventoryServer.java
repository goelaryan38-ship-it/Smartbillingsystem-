package com.inventory.server;

import com.inventory.controller.ApiController;
import com.inventory.service.*;
import com.sun.net.httpserver.*;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;

public class InventoryServer {
    private final int port; private final ApiController api;
    public InventoryServer(int port,InventoryService i,SalesService s){this.port=port;this.api=new ApiController(i,s);}
    public void start() throws IOException {
        HttpServer server=HttpServer.create(new InetSocketAddress("0.0.0.0",port),0);
        server.createContext("/api/",this::handleApi);server.createContext("/",this::staticFiles);
        server.setExecutor(java.util.concurrent.Executors.newFixedThreadPool(8));server.start();
        System.out.println("Smart Inventory server running at http://localhost:"+port);
    }
    private void handleApi(HttpExchange x) throws IOException {
        try {
            String path=x.getRequestURI().getPath(), method=x.getRequestMethod(), response="{}"; int status=200;
            if(path.equals("/api/products")&&method.equals("GET"))response=api.products();
            else if(path.equals("/api/products")&&method.equals("POST"))response=api.saveProduct(Json.parseFlat(readBody(x)));
            else if(path.matches("/api/products/\\d+")&&method.equals("DELETE")){boolean ok=api.deleteProduct(Integer.parseInt(path.substring(path.lastIndexOf('/')+1)));response="{\"deleted\":"+ok+"}";}
            else if(path.equals("/api/analytics"))response=api.analytics();
            else if(path.equals("/api/low-stock"))response=api.lowStock();
            else if(path.equals("/api/sales")&&method.equals("GET"))response=api.recentSales();
            else if(path.equals("/api/sales")&&method.equals("POST"))response=api.createSale(Json.parseFlat(readBody(x)));
            else {status=404;response="{\"error\":\"Endpoint not found\"}";}
            send(x,status,response,"application/json; charset=utf-8");
        } catch(Exception e){send(x,400,"{\"error\":\""+Json.escape(e.getMessage()==null?"Request failed":e.getMessage())+"\"}","application/json; charset=utf-8");}
    }
    private String readBody(HttpExchange x)throws IOException{return new String(x.getRequestBody().readAllBytes(),StandardCharsets.UTF_8);}
    private void staticFiles(HttpExchange x)throws IOException {
        String path=x.getRequestURI().getPath(); if(path.equals("/"))path="/index.html";
        String relative=path.substring(1);
        if(relative.contains("..") || relative.contains("\\")){send(x,404,"Not found","text/plain");return;}
        byte[] bytes;
        try(InputStream in=getClass().getClassLoader().getResourceAsStream("web/"+relative)) {
            if(in!=null) bytes=in.readAllBytes();
            else {
                Path file=Path.of("src/main/resources/web").resolve(relative).normalize();
                Path base=Path.of("src/main/resources/web").toAbsolutePath().normalize();
                if(!file.toAbsolutePath().normalize().startsWith(base)||!Files.exists(file)||Files.isDirectory(file)){send(x,404,"Not found","text/plain");return;}
                bytes=Files.readAllBytes(file);
            }
        }
        String type=relative.endsWith(".css")?"text/css; charset=utf-8":relative.endsWith(".js")?"application/javascript; charset=utf-8":"text/html; charset=utf-8";
        sendBytes(x,200,bytes,type);
    }
    private void send(HttpExchange x,int status,String body,String type)throws IOException {
        sendBytes(x,status,body.getBytes(StandardCharsets.UTF_8),type.trim());
    }
    private void sendBytes(HttpExchange x,int status,byte[] bytes,String type)throws IOException {
        x.getResponseHeaders().set("Content-Type",type);x.getResponseHeaders().set("Access-Control-Allow-Origin","*");
        x.sendResponseHeaders(status,bytes.length);
        try(OutputStream os=x.getResponseBody()){os.write(bytes);}
    }
}
