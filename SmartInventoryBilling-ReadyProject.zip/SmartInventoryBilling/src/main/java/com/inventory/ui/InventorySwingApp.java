package com.inventory.ui;

import com.inventory.dao.ProductDao;
import com.inventory.model.*;
import com.inventory.service.InventoryService;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

public class InventorySwingApp {
    public static void main(String[] args){SwingUtilities.invokeLater(()->new InventorySwingApp().show());}
    private final InventoryService service=new InventoryService(new ProductDao());
    private final DefaultTableModel model=new DefaultTableModel(new Object[]{"ID","SKU","Product","Category","Price","Stock"},0);
    private void show(){
        JFrame frame=new JFrame("Smart Inventory — Java Swing Admin");frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);frame.setSize(850,520);frame.setLocationRelativeTo(null);
        JTable table=new JTable(model);JButton refresh=new JButton("Refresh"),add=new JButton("Add demo product");
        JLabel info=new JLabel(new Admin("Administrator").dashboardMessage());
        refresh.addActionListener(e->load());add.addActionListener(e->{
            try{service.save(new Product("SW-"+System.currentTimeMillis(),"Swing Demo Item","Demo",299,10,3));load();}
            catch(Exception ex){JOptionPane.showMessageDialog(frame,ex.getMessage(),"Error",JOptionPane.ERROR_MESSAGE);}
        });
        JPanel top=new JPanel(new FlowLayout(FlowLayout.LEFT));top.add(info);top.add(refresh);top.add(add);
        frame.add(top,BorderLayout.NORTH);frame.add(new JScrollPane(table),BorderLayout.CENTER);frame.setVisible(true);load();
        User user=new Cashier("Demo Cashier");info.setText(user.dashboardMessage()); // dynamic dispatch through User reference
    }
    private void load(){
        try{model.setRowCount(0);for(Product p:service.all())model.addRow(new Object[]{p.getId(),p.getSku(),p.getName(),p.getCategory(),p.getPrice(),p.getStock()});}
        catch(Exception ex){JOptionPane.showMessageDialog(null,ex.getMessage(),"Database error",JOptionPane.ERROR_MESSAGE);}
    }
}
