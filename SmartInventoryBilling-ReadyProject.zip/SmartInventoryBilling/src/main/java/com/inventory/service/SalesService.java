package com.inventory.service;

import com.inventory.dao.ProductDao;
import com.inventory.dao.SaleDao;
import com.inventory.exception.ValidationException;
import com.inventory.model.*;
import java.util.*;

public class SalesService {
    private final ProductDao productDao; private final SaleDao saleDao;
    private final Billable calculator=(items,prices)->items.stream().mapToDouble(i->prices.getOrDefault(i.getProductId(),0.0)*i.getQuantity()).sum();
    public SalesService(ProductDao p,SaleDao s){this.productDao=p;this.saleDao=s;}
    public SaleResult create(String customer,List<SaleItemRequest> items) throws Exception {
        if(customer==null || customer.isBlank()) throw new ValidationException("Customer name is required.");
        if(items==null || items.isEmpty()) throw new ValidationException("Add at least one item.");
        Map<Integer,Product> products=new HashMap<>(); Map<Integer,Double> prices=new HashMap<>();
        for(SaleItemRequest i:items) {
            if(i.getQuantity()<=0) throw new ValidationException("Quantity must be greater than zero.");
            Product p=productDao.findById(i.getProductId()).orElseThrow(()->new ValidationException("Product not found."));
            if(p.getStock()<i.getQuantity()) throw new ValidationException("Not enough stock for "+p.getName());
            products.put(p.getId(),p); prices.put(p.getId(),p.getPrice());
        }
        double subtotal=calculator.calculateSubtotal(items,prices), tax=Math.round(subtotal*0.05*100.0)/100.0, total=subtotal+tax;
        String invoice="INV-"+System.currentTimeMillis();
        int id=saleDao.createSale(invoice,customer,subtotal,tax,total,items,products);
        List<String> summary=items.stream().map(i->products.get(i.getProductId()).getName()+" × "+i.getQuantity()).toList();
        return new SaleResult(id,invoice,customer,subtotal,tax,total,summary);
    }
    public List<Map<String,Object>> recent() throws Exception{return saleDao.findRecent();}
    public Map<String,Object> summary() throws Exception{return saleDao.summary();}
}
