package com.inventory.service;

import com.inventory.dao.ProductDao;
import java.util.concurrent.*;

public class LowStockMonitor {
    private final ProductDao dao;
    private final ScheduledExecutorService executor=Executors.newSingleThreadScheduledExecutor(r->{Thread t=new Thread(r,"low-stock-monitor");t.setDaemon(true);return t;});
    public LowStockMonitor(ProductDao dao){this.dao=dao;}
    public void start(){
        executor.scheduleAtFixedRate(()->{
            try { long count=dao.findAll().stream().filter(p->p.getStock()<=p.getReorderLevel()).count();
                if(count>0) System.out.println("[STOCK MONITOR] "+count+" product(s) at/below reorder level.");
            } catch(Exception e){System.err.println("[STOCK MONITOR] "+e.getMessage());}
        },5,60,TimeUnit.SECONDS);
    }
}
