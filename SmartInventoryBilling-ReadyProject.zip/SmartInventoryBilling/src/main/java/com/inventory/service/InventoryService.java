package com.inventory.service;

import com.inventory.dao.ProductDao;
import com.inventory.exception.ValidationException;
import com.inventory.model.Product;
import java.util.*;
import java.util.stream.Collectors;

public class InventoryService {
    private final ProductDao dao;
    public InventoryService(ProductDao dao){this.dao=dao;}
    public List<Product> all() throws Exception{return dao.findAll();}
    public Product save(Product p) throws Exception {
        if(p.getSku()==null || p.getSku().isBlank()) throw new ValidationException("SKU is required.");
        if(p.getName()==null || p.getName().isBlank()) throw new ValidationException("Product name is required.");
        if(p.getPrice()<0 || p.getStock()<0 || p.getReorderLevel()<0) throw new ValidationException("Price and stock values cannot be negative.");
        return dao.save(p);
    }
    public boolean delete(int id) throws Exception{return dao.delete(id);}
    public List<Product> lowStock() throws Exception {
        return dao.findAll().stream().filter(Product::isLowStock).collect(Collectors.toList());
    }
    public Map<String,Object> analytics() throws Exception {
        List<Product> products=dao.findAll();
        double inventoryValue=products.stream().map(p->p.getPrice()*p.getStock()).reduce(0.0,Double::sum);
        long low=products.stream().filter(Product::isLowStock).count();
        Map<String,Object> m=new LinkedHashMap<>();m.put("productCount",products.size());m.put("inventoryValue",inventoryValue);m.put("lowStockCount",low);
        m.put("categories",products.stream().map(Product::getCategory).distinct().sorted().toList()); return m;
    }
}
