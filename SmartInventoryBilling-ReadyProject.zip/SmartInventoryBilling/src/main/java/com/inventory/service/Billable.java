package com.inventory.service;

import java.util.List;
import com.inventory.model.SaleItemRequest;

@FunctionalInterface
public interface Billable {
    double calculateSubtotal(List<SaleItemRequest> items, java.util.Map<Integer, Double> prices);
}
