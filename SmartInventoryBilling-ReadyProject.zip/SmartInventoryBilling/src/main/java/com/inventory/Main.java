package com.inventory;

import com.inventory.dao.ProductDao;
import com.inventory.dao.SaleDao;
import com.inventory.server.InventoryServer;
import com.inventory.service.InventoryService;
import com.inventory.service.SalesService;
import com.inventory.service.LowStockMonitor;

public class Main {
    public static void main(String[] args) throws Exception {
        ProductDao productDao = new ProductDao();
        SaleDao saleDao = new SaleDao();
        InventoryService inventoryService = new InventoryService(productDao);
        SalesService salesService = new SalesService(productDao, saleDao);
        LowStockMonitor monitor = new LowStockMonitor(productDao);
        monitor.start();
        int port = Integer.parseInt(System.getenv().getOrDefault("PORT", "8080"));
        new InventoryServer(port, inventoryService, salesService).start();
    }
}
