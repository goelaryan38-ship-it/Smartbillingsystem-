# Smart Inventory & Billing Management System

A ready-to-run Java 17 + MySQL project with a responsive browser dashboard, Java HTTP backend,
JDBC/PreparedStatement CRUD, invoice generation, background stock monitoring, Java Swing desktop
admin screen, MVC separation, interfaces, inheritance, polymorphism, lambdas and Stream API.

## 1. Requirements
- JDK 17 or newer
- Maven 3.8+
- MySQL 8+
- Browser

## 2. Database setup
1. Open MySQL Workbench or terminal.
2. Run `database/schema.sql`.
3. The script creates database `smart_inventory` and demo records.

## 3. Configure database
Set environment variables before starting:
- `DB_URL` (default `jdbc:mysql://localhost:3306/smart_inventory?useSSL=false&serverTimezone=UTC`)
- `DB_USER` (default `root`)
- `DB_PASSWORD` (default `root`)

Windows PowerShell example:
```powershell
$env:DB_USER="root"
$env:DB_PASSWORD="your_mysql_password"
mvn clean compile exec:java
```
macOS/Linux:
```bash
export DB_USER=root
export DB_PASSWORD='your_mysql_password'
mvn clean compile exec:java
```
Then open **http://localhost:8080**.

## 4. Demo data
The SQL script inserts sample products. Add, edit, delete, search, create bills and inspect
sales reports from the website. The first run uses your local MySQL database.

## 5. Java Swing GUI
With the server running, open a second terminal:
```bash
mvn exec:java -Dexec.mainClass=com.inventory.ui.InventorySwingApp
```
The Swing window is a desktop admin interface using the same service and DAO layers.

## 6. Tests
```bash
mvn test
```
Tests cover validation and invoice calculations. Database integration can be demonstrated by
running the app against the MySQL schema.

## 7. Hosting online
This project is ready to run locally. To deploy publicly, use a Java-capable host (Render,
Railway, VPS, etc.) and a managed MySQL database. Set `PORT`, `DB_URL`, `DB_USER`, `DB_PASSWORD`
as environment variables. Do not expose database credentials in frontend files. For public
deployment, configure HTTPS, authentication/authorization, backups, and restrict CORS before
using real business data. This academic demo intentionally has no production authentication.

## 8. Project structure
- `model/`: domain objects and inheritance
- `dao/`: JDBC persistence and PreparedStatement CRUD
- `service/`: business rules, validation, billing, Stream API
- `controller/`: HTTP API controllers
- `server/`: Java HTTP server and request routing
- `ui/`: Swing MVC desktop interface
- `resources/`: web frontend
- `database/`: MySQL schema and sample data
- `tests/`: JUnit tests

## 9. Requirement mapping
1. OOP: encapsulated Product, User hierarchy, overridden methods, dynamic dispatch in `User`.
2. Classes/objects: constructors, overloaded constructors, `this` usage in models.
3. Interfaces/packages: `Repository<T>`, `Billable`, `model`, `dao`, `service`, etc.
4. Core Java: primitives, variables, operators, conditions, loops, arrays and methods.
5. Exceptions: custom `ValidationException`, try/catch/finally in JDBC, API error handling and input validation.
6. JDBC: MySQL connection and Product/Sale CRUD using PreparedStatement.
7. Multithreading: scheduled low-stock monitor runs on a daemon background thread.
8. Functional programming: `filter`, `map`, `reduce`, lambdas and functional interface.
9. GUI/MVC: browser UI + Java HTTP controller/service/DAO separation; additional Swing MVC client.
10. Testing/demo: JUnit tests, sample database records, README demo steps.

## 10. Suggested live demonstration
1. Show dashboard totals and product list.
2. Add a product, edit its price/stock, then delete it.
3. Create a bill with multiple products and show stock reduction.
4. Open Sales and Analytics and show the generated totals.
5. Set a product stock below its reorder level and show the low-stock alert.
6. Explain the Java classes, interface, thread, Stream API and Swing MVC screen.
